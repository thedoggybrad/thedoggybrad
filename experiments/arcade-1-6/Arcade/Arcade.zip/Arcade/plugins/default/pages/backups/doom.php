<p></p>
<p>DOOM</p>
<p>
	<button class="btn btn-primary" align="center" onclick="NewTab()"> 
    FULLSCREEN 
    </button> 
    <script> 
        function NewTab() { 
            window.open("https://dos.zone/en/play/https%3A%2F%2Fdoszone-uploads.s3.dualstack.eu-central-1.amazonaws.com%2Foriginal%2F2X%2F8%2F80ba33210cab4177158dde6f2ec9704de56c7dfc.jsdos?turbo=0&turboRegion=auto", 
                    "", "width=888, height=666"); 
        } 
    </script>
</p>
<p>
<div class="icontainer">
  <iframe class="responsive-iframe" src="https://dos.zone/en/play/https%3A%2F%2Fdoszone-uploads.s3.dualstack.eu-central-1.amazonaws.com%2Foriginal%2F2X%2F8%2F80ba33210cab4177158dde6f2ec9704de56c7dfc.jsdos?turbo=0&turboRegion=auto" frameborder="0"></iframe>
</div>
</p>
