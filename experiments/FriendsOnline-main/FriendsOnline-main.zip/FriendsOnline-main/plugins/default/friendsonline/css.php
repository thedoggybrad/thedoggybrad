.menu-section-item-friendsonline:before {
    content: "\f0c0" !important;
}
.friendsonline-widget .user-img {
    border: 2px solid green;
}