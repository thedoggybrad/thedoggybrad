<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="Speedtest Feature">
	<title>Speedtest - Powered by OpenSpeedTest</title>
</head>
<body>
<div class="icontainer">
<!--OST Widget code start--><div style="text-align:right;"><div style="min-height:360px;"><div style="width:100%;height:0;padding-bottom:50%;position:relative;"><iframe lass="responsive-iframe" style="border:none;position:absolute;top:0;left:0;width:100%;height:100%;min-height:360px;border:none;overflow:hidden !important;" src="//openspeedtest.com/speedtest"></iframe></div></div>Provided by <a href="https://openspeedtest.com">OpenSpeedtest.com</a></div><!-- OST Widget code end -->
	</div>
<br>
	<button class="btn btn-primary" align="center" onclick="NewTab()"> 
    Open in new tab
    </button> 
    <script> 
        function NewTab() { 
            window.open("https://www.google.com/webhp?igu=1", 
                    "", "width=850, height=650"); 
        } 
    </script>
</body>