<iframe src="https://funhtml5games.com?embed=sonic" style="width:496px;height:555px;border:none;" frameborder="0" scrolling="no"></iframe>
<p>
	<button class="btn btn-primary" align="center" onclick="NewTab()"> 
    FULLSCREEN 
    </button> 
    <script> 
        function NewTab() { 
            window.open("https://funhtml5games.com/sms/?play=sonic", 
                    "", "width=100%, height=100%"); 
        } 
    </script>
</p>