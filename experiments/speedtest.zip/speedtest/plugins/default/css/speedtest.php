.menu-section-item-speedtest:before {
    font-family: FontAwesome;
    content: "\f628"; }

.icontainer {
  position: relative;
  overflow: hidden;
  width: 100%;
}
.responsive-iframe {
  position: absolute;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
  width: 100%;
  height: 100%;
}