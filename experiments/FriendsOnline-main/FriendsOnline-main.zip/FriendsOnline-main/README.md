# FriendsOnline
Show friends online page and widget
